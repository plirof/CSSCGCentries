<?php
//for debugging
//echo $_REQUEST["mytext"];

$table_var_array=["CTL","VOC","STX","MTX","OTX","LTX","CON","OBJ","PRO0","PRO1","PRO2","PRO3","PRO4","PRO5","PRO6","PRO7","PRO8","PRO9","PRO10"];

for($i = 0; $i <= 18; $i++) {
     echo "<hr>";
     ${$table_var_array[$i]} = $table_var_array[$i];
     //echo " <a href=#${$table_var_array[$i]}>$table_var_array[$i]</a> |";//."<br>";
     
     echo "/${$table_var_array[$i]}]<pre>";
     echo $_REQUEST["text_entered_${$table_var_array[$i]}"]; //">$table_var_array[$i]</a> |";//."<br>";


	 echo "</pre><hr>";
}



echo "<hr>";
//print_r($_REQUEST);
//var_dump($_REQUEST);

?>