
---------------------------------------------------------------
|    Sinclair Blind Flight Simulator 2 - Flying the plane     |
---------------------------------------------------------------
---------------
Introduction.
---------------
This is the sequel from the award winning game & multi-ported "Sinclair Blind Flight Simulator" 
that should have won the CCSCGC 2009.
(Note: This is NOTE a complete copy of the prequel's manual. 
A lot of effort has been in creating this HUGE manual for this AWESOME Simulator game)
Have you ever wondered how blind pilots are trained in flying plains?
Now live the thrills of trying this amazing piece of software
This is a RPG game where you control a pilot that has to encounter various 
challenges that change as you progress.


-------------
Instructions:
-------------
-Select a monitor type. 
-Use the normal commands to fly the plane (eg. n,s,e,w)

---------------
Main features :
---------------
-Realistic graphics of the whole flight!!!
-The air-flight control uses one of the most sophisticated AI system.
-A team of professional flight pilots were hired 
  just to make sure that everything is implemented 
  perfectly & the game is realistic
-RPG style game as each pilot * airplane has its own unique characteristics & can make his own unique decisions.

  
---------------  
Requirements:
---------------
-A spectrum

---------------
Known Bugs:
---------------
-None. All are features!


---------------------------------------------
What people & entities have to say about this game :
---------------------------------------------
BSFF organization - Best game I 've ever played
BSFD organization - Best simulator I've used
BSLA to BSLZ - AMAZING !!!
Royal Airforce - BFSDBIEGOCECMCOMRCP{ECM{P}

---------------------------------------------
Troubleshooting
---------------------------------------------
Our company policy is against shooting when there is trouble.




---------------------------------------------
(C) Firelord 2009 - trister12[at]yahoo[dot]com  (please include the word SPECTRUM somewhere in the Subject of the mail. 
Have Fun :D !!!





