SpectrumXAMPP 
XAMPP port for Spectrum 2010(c)
This is NOT a game. It's a developer tool that includes Apache,MySQL & Php.
Ported & Compiled for Spectrum by Firelord Quality Games LTD.
---------------------------------------------------------
Introduction taken from the XAMPP home site 
(http://www.apachefriends.org/en/xampp.html)

"Many people know from their own experience that it's not easy to 
install an Apache web server and it gets harder if you want to 
add MySQL, PHP and Perl.
XAMPP is an easy to install Apache distribution containing MySQL, 
PHP and Perl. XAMPP is really very easy to install and to use - 
just download, extract and start.

At the moment there are five XAMPP distributions:
-XAMPP for Linux 
-XAMPP for Windows 
-XAMPP for Mac OS X 
-XAMPP for Solaris 
-XAMPP for zx spectrum.

All the versions are free except the spectrum version where you must send money to Firelord!!!
"
---------------------------------------------------------

Installation :
Just connect your spectrum to your router and run the .SNA file provided .
